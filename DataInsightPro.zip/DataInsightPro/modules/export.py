import pandas as pd
import json
import io
from typing import Dict, Any, Optional, List
import csv
import xlsxwriter

class DataExport:
    """Handle data export in various formats"""
    
    def __init__(self):
        self.supported_formats = ['csv', 'json', 'excel', 'parquet', 'html']
    
    def to_csv(self, data: pd.DataFrame, include_index: bool = False, 
               separator: str = ',', encoding: str = 'utf-8') -> str:
        """Export data to CSV format"""
        try:
            output = io.StringIO()
            data.to_csv(output, index=include_index, sep=separator, encoding=encoding)
            csv_string = output.getvalue()
            output.close()
            return csv_string
            
        except Exception as e:
            raise Exception(f"Failed to export to CSV: {str(e)}")
    
    def to_json(self, data: pd.DataFrame, orient: str = 'records', 
                indent: int = 2, date_format: str = 'iso') -> str:
        """Export data to JSON format"""
        try:
            json_string = data.to_json(orient=orient, indent=indent, date_format=date_format)
            return json_string
            
        except Exception as e:
            raise Exception(f"Failed to export to JSON: {str(e)}")
    
    def to_excel(self, data: pd.DataFrame, include_index: bool = False, 
                 sheet_name: str = 'Sheet1') -> bytes:
        """Export data to Excel format"""
        try:
            output = io.BytesIO()
            
            with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
                data.to_excel(writer, sheet_name=sheet_name, index=include_index)
                
                # Get the xlsxwriter workbook and worksheet objects
                workbook = writer.book
                worksheet = writer.sheets[sheet_name]
                
                # Add some formatting
                header_format = workbook.add_format({
                    'bold': True,
                    'text_wrap': True,
                    'valign': 'top',
                    'fg_color': '#D7E4BC',
                    'border': 1
                })
                
                # Write the column headers with formatting
                for col_num, value in enumerate(data.columns.values):
                    worksheet.write(0, col_num, value, header_format)
                
                # Auto-adjust column widths
                for i, col in enumerate(data.columns):
                    max_length = max(
                        data[col].astype(str).map(len).max(),
                        len(str(col))
                    )
                    worksheet.set_column(i, i, min(max_length + 2, 50))
            
            excel_bytes = output.getvalue()
            output.close()
            return excel_bytes
            
        except Exception as e:
            raise Exception(f"Failed to export to Excel: {str(e)}")
    
    def to_parquet(self, data: pd.DataFrame) -> bytes:
        """Export data to Parquet format"""
        try:
            output = io.BytesIO()
            data.to_parquet(output, index=False)
            parquet_bytes = output.getvalue()
            output.close()
            return parquet_bytes
            
        except Exception as e:
            raise Exception(f"Failed to export to Parquet: {str(e)}")
    
    def to_html(self, data: pd.DataFrame, include_index: bool = False,
                table_id: str = 'data-table', classes: str = 'table table-striped') -> str:
        """Export data to HTML format"""
        try:
            html_string = data.to_html(
                index=include_index,
                table_id=table_id,
                classes=classes,
                escape=False
            )
            return html_string
            
        except Exception as e:
            raise Exception(f"Failed to export to HTML: {str(e)}")
    
    def create_export_summary(self, data: pd.DataFrame, export_format: str,
                             include_metadata: bool = True) -> Dict[str, Any]:
        """Create export summary with metadata"""
        try:
            summary = {
                'export_format': export_format,
                'timestamp': pd.Timestamp.now().isoformat(),
                'record_count': len(data),
                'column_count': len(data.columns),
                'columns': data.columns.tolist()
            }
            
            if include_metadata:
                summary.update({
                    'data_types': data.dtypes.to_dict(),
                    'memory_usage': data.memory_usage(deep=True).sum(),
                    'missing_values': data.isnull().sum().to_dict()
                })
            
            return summary
            
        except Exception as e:
            return {'error': str(e)}
    
    def export_filtered_data(self, data: pd.DataFrame, filters: Dict[str, Any],
                            export_format: str = 'csv') -> str:
        """Export filtered data based on provided filters"""
        try:
            filtered_data = data.copy()
            
            # Apply filters
            for column, filter_config in filters.items():
                if column not in filtered_data.columns:
                    continue
                
                if isinstance(filter_config, dict):
                    # Range filter for numeric columns
                    if 'min' in filter_config and 'max' in filter_config:
                        filtered_data = filtered_data[
                            (filtered_data[column] >= filter_config['min']) &
                            (filtered_data[column] <= filter_config['max'])
                        ]
                    
                    # Value filter for categorical columns
                    elif 'values' in filter_config:
                        filtered_data = filtered_data[
                            filtered_data[column].isin(filter_config['values'])
                        ]
                
                elif isinstance(filter_config, list):
                    # Direct value list
                    filtered_data = filtered_data[
                        filtered_data[column].isin(filter_config)
                    ]
            
            # Export filtered data
            if export_format.lower() == 'csv':
                return self.to_csv(filtered_data)
            elif export_format.lower() == 'json':
                return self.to_json(filtered_data)
            elif export_format.lower() == 'html':
                return self.to_html(filtered_data)
            else:
                raise ValueError(f"Unsupported export format: {export_format}")
                
        except Exception as e:
            raise Exception(f"Failed to export filtered data: {str(e)}")
    
    def export_with_formatting(self, data: pd.DataFrame, format_config: Dict[str, Any],
                              export_format: str = 'excel') -> bytes:
        """Export data with custom formatting"""
        try:
            if export_format.lower() != 'excel':
                raise ValueError("Custom formatting only supported for Excel export")
            
            output = io.BytesIO()
            
            with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
                data.to_excel(writer, sheet_name='Data', index=False)
                
                workbook = writer.book
                worksheet = writer.sheets['Data']
                
                # Apply custom formatting
                if 'header_format' in format_config:
                    header_format = workbook.add_format(format_config['header_format'])
                    for col_num, value in enumerate(data.columns.values):
                        worksheet.write(0, col_num, value, header_format)
                
                if 'column_formats' in format_config:
                    for col_name, format_dict in format_config['column_formats'].items():
                        if col_name in data.columns:
                            col_num = data.columns.get_loc(col_name)
                            cell_format = workbook.add_format(format_dict)
                            worksheet.set_column(col_num, col_num, None, cell_format)
                
                if 'column_widths' in format_config:
                    for col_name, width in format_config['column_widths'].items():
                        if col_name in data.columns:
                            col_num = data.columns.get_loc(col_name)
                            worksheet.set_column(col_num, col_num, width)
            
            excel_bytes = output.getvalue()
            output.close()
            return excel_bytes
            
        except Exception as e:
            raise Exception(f"Failed to export with formatting: {str(e)}")
    
    def get_export_info(self, data: pd.DataFrame, export_format: str) -> Dict[str, Any]:
        """Get information about export operation"""
        try:
            info = {
                'format': export_format,
                'source_shape': data.shape,
                'estimated_size': self._estimate_export_size(data, export_format),
                'supported_features': self._get_format_features(export_format)
            }
            
            return info
            
        except Exception as e:
            return {'error': str(e)}
    
    def _estimate_export_size(self, data: pd.DataFrame, export_format: str) -> str:
        """Estimate export file size"""
        try:
            # Rough estimation based on data size and format
            base_size = data.memory_usage(deep=True).sum()
            
            if export_format.lower() == 'csv':
                estimated_size = base_size * 1.2  # CSV is roughly 20% larger
            elif export_format.lower() == 'json':
                estimated_size = base_size * 1.5  # JSON is roughly 50% larger
            elif export_format.lower() == 'excel':
                estimated_size = base_size * 1.3  # Excel is roughly 30% larger
            elif export_format.lower() == 'parquet':
                estimated_size = base_size * 0.3  # Parquet is compressed
            else:
                estimated_size = base_size
            
            # Convert to human readable format
            if estimated_size < 1024:
                return f"{estimated_size:.0f} bytes"
            elif estimated_size < 1024**2:
                return f"{estimated_size/1024:.1f} KB"
            elif estimated_size < 1024**3:
                return f"{estimated_size/(1024**2):.1f} MB"
            else:
                return f"{estimated_size/(1024**3):.1f} GB"
                
        except Exception:
            return "Unknown"
    
    def _get_format_features(self, export_format: str) -> List[str]:
        """Get supported features for export format"""
        format_features = {
            'csv': ['Lightweight', 'Universal compatibility', 'No formatting'],
            'json': ['Structured data', 'Web-friendly', 'Hierarchical support'],
            'excel': ['Rich formatting', 'Multiple sheets', 'Formulas'],
            'parquet': ['Compressed', 'Fast reading', 'Schema preservation'],
            'html': ['Web display', 'Styled tables', 'Interactive elements']
        }
        
        return format_features.get(export_format.lower(), ['Unknown format'])
