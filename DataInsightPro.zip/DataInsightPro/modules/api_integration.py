import requests
import pandas as pd
import json
from typing import Dict, Optional, Any, List
import urllib.parse
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

class APIIntegration:
    """Handle API integrations and data fetching"""
    
    def __init__(self):
        self.session = requests.Session()
        self.setup_retry_strategy()
    
    def setup_retry_strategy(self):
        """Setup retry strategy for API calls"""
        retry_strategy = Retry(
            total=3,
            status_forcelist=[429, 500, 502, 503, 504],
            method_whitelist=["HEAD", "GET", "OPTIONS"]
        )
        
        adapter = HTTPAdapter(max_retries=retry_strategy)
        self.session.mount("http://", adapter)
        self.session.mount("https://", adapter)
    
    def fetch_from_api(self, url: str, api_key: Optional[str] = None,
                      headers: Optional[Dict[str, str]] = None,
                      params: Optional[Dict[str, Any]] = None,
                      timeout: int = 30) -> pd.DataFrame:
        """Fetch data from REST API endpoint"""
        try:
            # Setup headers
            request_headers = {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
            
            if headers:
                request_headers.update(headers)
            
            # Add API key to headers if provided
            if api_key:
                request_headers['Authorization'] = f'Bearer {api_key}'
            
            # Make request
            response = self.session.get(
                url,
                headers=request_headers,
                params=params,
                timeout=timeout
            )
            
            # Check response status
            response.raise_for_status()
            
            # Parse JSON response
            data = response.json()
            
            # Convert to DataFrame
            if isinstance(data, list):
                df = pd.DataFrame(data)
            elif isinstance(data, dict):
                # Handle different response structures
                if 'data' in data:
                    df = pd.DataFrame(data['data'])
                elif 'results' in data:
                    df = pd.DataFrame(data['results'])
                elif 'items' in data:
                    df = pd.DataFrame(data['items'])
                else:
                    # Try to flatten the dictionary
                    df = pd.json_normalize(data)
            else:
                raise ValueError("Unsupported response format")
            
            return df
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"API request failed: {str(e)}")
        except json.JSONDecodeError as e:
            raise Exception(f"Failed to parse JSON response: {str(e)}")
        except Exception as e:
            raise Exception(f"API integration error: {str(e)}")
    
    def post_to_api(self, url: str, data: Dict[str, Any],
                   api_key: Optional[str] = None,
                   headers: Optional[Dict[str, str]] = None,
                   timeout: int = 30) -> Dict[str, Any]:
        """Post data to API endpoint"""
        try:
            # Setup headers
            request_headers = {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
            
            if headers:
                request_headers.update(headers)
            
            # Add API key to headers if provided
            if api_key:
                request_headers['Authorization'] = f'Bearer {api_key}'
            
            # Make request
            response = self.session.post(
                url,
                headers=request_headers,
                json=data,
                timeout=timeout
            )
            
            # Check response status
            response.raise_for_status()
            
            # Parse JSON response
            return response.json()
            
        except requests.exceptions.RequestException as e:
            raise Exception(f"API POST request failed: {str(e)}")
        except json.JSONDecodeError as e:
            raise Exception(f"Failed to parse JSON response: {str(e)}")
        except Exception as e:
            raise Exception(f"API POST error: {str(e)}")
    
    def fetch_paginated_data(self, base_url: str, api_key: Optional[str] = None,
                            page_param: str = 'page',
                            per_page_param: str = 'per_page',
                            per_page: int = 100,
                            max_pages: int = 10) -> pd.DataFrame:
        """Fetch paginated data from API"""
        try:
            all_data = []
            page = 1
            
            while page <= max_pages:
                # Setup parameters
                params = {
                    page_param: page,
                    per_page_param: per_page
                }
                
                # Fetch page data
                page_data = self.fetch_from_api(base_url, api_key, params=params)
                
                if page_data.empty:
                    break
                
                all_data.append(page_data)
                
                # Check if we've reached the end
                if len(page_data) < per_page:
                    break
                
                page += 1
            
            # Combine all pages
            if all_data:
                return pd.concat(all_data, ignore_index=True)
            else:
                return pd.DataFrame()
                
        except Exception as e:
            raise Exception(f"Paginated API fetch failed: {str(e)}")
    
    def validate_api_response(self, response_data: Any) -> bool:
        """Validate API response structure"""
        try:
            if isinstance(response_data, (list, dict)):
                return True
            return False
            
        except Exception:
            return False
    
    def build_api_url(self, base_url: str, endpoint: str, params: Optional[Dict[str, Any]] = None) -> str:
        """Build complete API URL with parameters"""
        try:
            # Join base URL and endpoint
            url = urllib.parse.urljoin(base_url, endpoint)
            
            # Add parameters if provided
            if params:
                url_parts = list(urllib.parse.urlparse(url))
                query = dict(urllib.parse.parse_qsl(url_parts[4]))
                query.update(params)
                url_parts[4] = urllib.parse.urlencode(query)
                url = urllib.parse.urlunparse(url_parts)
            
            return url
            
        except Exception as e:
            raise Exception(f"Failed to build API URL: {str(e)}")
    
    def get_api_info(self, url: str, api_key: Optional[str] = None) -> Dict[str, Any]:
        """Get information about API endpoint"""
        try:
            # Try to get API info/documentation endpoint
            info_endpoints = [
                '/info',
                '/docs',
                '/swagger.json',
                '/api-docs',
                '/'
            ]
            
            for endpoint in info_endpoints:
                try:
                    info_url = urllib.parse.urljoin(url, endpoint)
                    response = self.session.get(info_url, timeout=10)
                    
                    if response.status_code == 200:
                        return {
                            'url': info_url,
                            'status': 'accessible',
                            'content_type': response.headers.get('content-type', 'unknown')
                        }
                except:
                    continue
            
            # If no info endpoint found, try basic HEAD request
            response = self.session.head(url, timeout=10)
            
            return {
                'url': url,
                'status': 'accessible' if response.status_code == 200 else 'error',
                'status_code': response.status_code,
                'headers': dict(response.headers)
            }
            
        except Exception as e:
            return {
                'url': url,
                'status': 'error',
                'error': str(e)
            }
    
    def close_session(self):
        """Close the requests session"""
        try:
            self.session.close()
        except:
            pass
