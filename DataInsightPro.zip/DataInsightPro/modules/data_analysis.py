import pandas as pd
import numpy as np
from scipy import stats
from scipy.stats import pearsonr, spearmanr
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import plotly.graph_objects as go
import plotly.express as px
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.stattools import adfuller
from typing import Dict, List, Optional, Tuple, Union
import warnings
warnings.filterwarnings('ignore')

class DataAnalysis:
    """Advanced data analysis and statistical operations"""
    
    def __init__(self):
        self.scaler = StandardScaler()
    
    def detect_date_columns(self, data: pd.DataFrame) -> List[str]:
        """Detect potential date columns in the dataset"""
        date_columns = []
        
        for col in data.columns:
            # Check if column is already datetime
            if pd.api.types.is_datetime64_any_dtype(data[col]):
                date_columns.append(col)
                continue
            
            # Try to convert to datetime
            try:
                pd.to_datetime(data[col].dropna().head(100))
                date_columns.append(col)
            except:
                continue
        
        return date_columns
    
    def prepare_time_series(self, data: pd.DataFrame, date_col: str, value_col: str) -> pd.DataFrame:
        """Prepare data for time series analysis"""
        try:
            # Create a copy and convert date column
            ts_data = data[[date_col, value_col]].copy()
            ts_data[date_col] = pd.to_datetime(ts_data[date_col])
            
            # Remove missing values
            ts_data = ts_data.dropna()
            
            # Sort by date
            ts_data = ts_data.sort_values(date_col)
            
            # Remove duplicates, keeping first occurrence
            ts_data = ts_data.drop_duplicates(subset=[date_col], keep='first')
            
            return ts_data
            
        except Exception as e:
            raise Exception(f"Failed to prepare time series data: {str(e)}")
    
    def calculate_trends(self, data: pd.DataFrame, date_col: str = None, value_col: str = None) -> Dict:
        """Calculate trend statistics for time series data"""
        try:
            if date_col is None:
                date_col = data.columns[0]
            if value_col is None:
                value_col = data.columns[1]
            
            # Convert dates to numeric for regression
            x = pd.to_datetime(data[date_col]).map(pd.Timestamp.timestamp)
            y = data[value_col].values
            
            # Linear regression
            slope, intercept, r_value, p_value, std_err = stats.linregress(x, y)
            
            # Determine trend direction
            if slope > 0:
                direction = "Upward"
            elif slope < 0:
                direction = "Downward"
            else:
                direction = "Stable"
            
            # Calculate percentage change
            if len(y) > 1:
                pct_change = ((y[-1] - y[0]) / y[0]) * 100
            else:
                pct_change = 0
            
            return {
                'slope': slope,
                'intercept': intercept,
                'r_squared': r_value**2,
                'p_value': p_value,
                'std_error': std_err,
                'direction': direction,
                'percentage_change': pct_change,
                'is_significant': p_value < 0.05
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def seasonal_decomposition(self, data: pd.DataFrame, value_col: str, period: int = None) -> Optional[go.Figure]:
        """Perform seasonal decomposition of time series"""
        try:
            # Ensure we have enough data points
            if len(data) < 24:
                return None
            
            # Set date column as index
            ts_data = data.set_index(data.columns[0])
            
            # Determine period if not provided
            if period is None:
                period = min(12, len(ts_data) // 2)
            
            # Perform decomposition
            decomposition = seasonal_decompose(ts_data[value_col], period=period, model='additive')
            
            # Create subplots
            fig = go.Figure()
            
            # Original series
            fig.add_trace(go.Scatter(
                x=ts_data.index,
                y=ts_data[value_col],
                mode='lines',
                name='Original',
                line=dict(color='blue')
            ))
            
            # Trend
            fig.add_trace(go.Scatter(
                x=ts_data.index,
                y=decomposition.trend,
                mode='lines',
                name='Trend',
                line=dict(color='red')
            ))
            
            # Seasonal
            fig.add_trace(go.Scatter(
                x=ts_data.index,
                y=decomposition.seasonal,
                mode='lines',
                name='Seasonal',
                line=dict(color='green')
            ))
            
            # Residual
            fig.add_trace(go.Scatter(
                x=ts_data.index,
                y=decomposition.resid,
                mode='lines',
                name='Residual',
                line=dict(color='orange')
            ))
            
            fig.update_layout(
                title='Seasonal Decomposition',
                xaxis_title='Date',
                yaxis_title='Value',
                height=600
            )
            
            return fig
            
        except Exception as e:
            return None
    
    def calculate_correlation(self, data: pd.DataFrame, method: str = 'pearson') -> pd.DataFrame:
        """Calculate correlation matrix"""
        try:
            numeric_data = data.select_dtypes(include=[np.number])
            
            if method == 'pearson':
                corr_matrix = numeric_data.corr(method='pearson')
            elif method == 'spearman':
                corr_matrix = numeric_data.corr(method='spearman')
            else:
                raise ValueError("Method must be 'pearson' or 'spearman'")
            
            return corr_matrix
            
        except Exception as e:
            raise Exception(f"Failed to calculate correlation: {str(e)}")
    
    def detect_outliers(self, data: pd.DataFrame, columns: List[str] = None, method: str = 'iqr') -> Dict:
        """Detect outliers in numeric columns"""
        try:
            if columns is None:
                columns = data.select_dtypes(include=[np.number]).columns.tolist()
            
            outliers = {}
            
            for col in columns:
                if col not in data.columns:
                    continue
                
                series = data[col].dropna()
                
                if method == 'iqr':
                    Q1 = series.quantile(0.25)
                    Q3 = series.quantile(0.75)
                    IQR = Q3 - Q1
                    lower_bound = Q1 - 1.5 * IQR
                    upper_bound = Q3 + 1.5 * IQR
                    
                    outlier_mask = (series < lower_bound) | (series > upper_bound)
                    outliers[col] = series[outlier_mask].index.tolist()
                
                elif method == 'zscore':
                    z_scores = np.abs(stats.zscore(series))
                    outlier_mask = z_scores > 3
                    outliers[col] = series[outlier_mask].index.tolist()
            
            return outliers
            
        except Exception as e:
            return {'error': str(e)}
    
    def perform_pca(self, data: pd.DataFrame, n_components: int = None) -> Dict:
        """Perform Principal Component Analysis"""
        try:
            # Select only numeric columns
            numeric_data = data.select_dtypes(include=[np.number])
            
            # Remove missing values
            clean_data = numeric_data.dropna()
            
            if clean_data.empty:
                raise ValueError("No valid numeric data for PCA")
            
            # Standardize the data
            scaled_data = self.scaler.fit_transform(clean_data)
            
            # Determine number of components
            if n_components is None:
                n_components = min(clean_data.shape[1], clean_data.shape[0] - 1)
            
            # Perform PCA
            pca = PCA(n_components=n_components)
            pca_result = pca.fit_transform(scaled_data)
            
            # Create results dictionary
            results = {
                'explained_variance_ratio': pca.explained_variance_ratio_.tolist(),
                'cumulative_variance': np.cumsum(pca.explained_variance_ratio_).tolist(),
                'components': pca.components_.tolist(),
                'feature_names': clean_data.columns.tolist(),
                'transformed_data': pca_result.tolist()
            }
            
            return results
            
        except Exception as e:
            return {'error': str(e)}
    
    def statistical_summary(self, data: pd.DataFrame) -> Dict:
        """Generate comprehensive statistical summary"""
        try:
            summary = {}
            
            # Basic statistics
            summary['basic_stats'] = {
                'shape': data.shape,
                'memory_usage': data.memory_usage(deep=True).sum(),
                'missing_values': data.isnull().sum().to_dict(),
                'duplicate_rows': data.duplicated().sum()
            }
            
            # Numeric columns analysis
            numeric_cols = data.select_dtypes(include=[np.number]).columns.tolist()
            if numeric_cols:
                summary['numeric_summary'] = data[numeric_cols].describe().to_dict()
            
            # Categorical columns analysis
            categorical_cols = data.select_dtypes(include=['object']).columns.tolist()
            if categorical_cols:
                summary['categorical_summary'] = {}
                for col in categorical_cols:
                    summary['categorical_summary'][col] = {
                        'unique_values': data[col].nunique(),
                        'top_values': data[col].value_counts().head(10).to_dict()
                    }
            
            # Data types
            summary['data_types'] = data.dtypes.to_dict()
            
            return summary
            
        except Exception as e:
            return {'error': str(e)}
    
    def test_stationarity(self, series: pd.Series) -> Dict:
        """Test for stationarity using Augmented Dickey-Fuller test"""
        try:
            # Remove missing values
            clean_series = series.dropna()
            
            # Perform ADF test
            result = adfuller(clean_series)
            
            return {
                'adf_statistic': result[0],
                'p_value': result[1],
                'critical_values': result[4],
                'is_stationary': result[1] < 0.05
            }
            
        except Exception as e:
            return {'error': str(e)}
