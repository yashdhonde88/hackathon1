import pandas as pd
import numpy as np
from scipy import stats
from typing import Dict, List, Any, Optional, Tuple
import warnings
warnings.filterwarnings('ignore')

class InsightGenerator:
    """Generate automated insights and patterns from data"""
    
    def __init__(self):
        self.significance_level = 0.05
        self.correlation_threshold = 0.5
        self.outlier_threshold = 3  # Z-score threshold
    
    def generate_insights(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Generate comprehensive insights from data"""
        try:
            insights = {
                'basic_stats': self._get_basic_statistics(data),
                'quality_insights': self._analyze_data_quality(data),
                'statistical_insights': self._generate_statistical_insights(data),
                'correlation_insights': self._analyze_correlations(data),
                'trend_insights': self._analyze_trends(data),
                'outlier_insights': self._detect_outliers(data),
                'distribution_insights': self._analyze_distributions(data),
                'categorical_insights': self._analyze_categorical_data(data)
            }
            
            return insights
            
        except Exception as e:
            return {'error': str(e)}
    
    def _get_basic_statistics(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Get basic statistical information"""
        try:
            numeric_cols = data.select_dtypes(include=[np.number]).columns
            categorical_cols = data.select_dtypes(include=['object']).columns
            
            return {
                'total_records': len(data),
                'total_columns': len(data.columns),
                'numeric_columns': len(numeric_cols),
                'categorical_columns': len(categorical_cols),
                'memory_usage_mb': data.memory_usage(deep=True).sum() / (1024**2),
                'missing_values_total': data.isnull().sum().sum(),
                'duplicate_records': data.duplicated().sum()
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def _analyze_data_quality(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Analyze data quality issues"""
        try:
            quality_insights = {
                'missing_data': {},
                'duplicates': data.duplicated().sum(),
                'data_types': data.dtypes.to_dict(),
                'completeness_score': 0
            }
            
            # Missing data analysis
            missing_counts = data.isnull().sum()
            missing_data = missing_counts[missing_counts > 0].to_dict()
            quality_insights['missing_data'] = missing_data
            
            # Calculate completeness score
            total_cells = data.shape[0] * data.shape[1]
            missing_cells = data.isnull().sum().sum()
            completeness_score = ((total_cells - missing_cells) / total_cells) * 100
            quality_insights['completeness_score'] = round(completeness_score, 2)
            
            return quality_insights
            
        except Exception as e:
            return {'error': str(e)}
    
    def _generate_statistical_insights(self, data: pd.DataFrame) -> List[str]:
        """Generate statistical insights from numeric data"""
        try:
            insights = []
            numeric_cols = data.select_dtypes(include=[np.number]).columns
            
            for col in numeric_cols:
                series = data[col].dropna()
                if len(series) == 0:
                    continue
                
                # Basic statistics
                mean_val = series.mean()
                median_val = series.median()
                std_val = series.std()
                
                # Skewness analysis
                skewness = series.skew()
                if abs(skewness) > 1:
                    skew_direction = "right" if skewness > 0 else "left"
                    insights.append(f"Column '{col}' is highly skewed to the {skew_direction} (skewness: {skewness:.2f})")
                
                # Variance analysis
                cv = (std_val / mean_val) * 100 if mean_val != 0 else 0
                if cv > 50:
                    insights.append(f"Column '{col}' shows high variability (CV: {cv:.1f}%)")
                
                # Range analysis
                data_range = series.max() - series.min()
                if data_range == 0:
                    insights.append(f"Column '{col}' has constant values")
                
                # Outlier detection
                z_scores = np.abs(stats.zscore(series))
                outliers = (z_scores > self.outlier_threshold).sum()
                if outliers > 0:
                    outlier_pct = (outliers / len(series)) * 100
                    insights.append(f"Column '{col}' has {outliers} outliers ({outlier_pct:.1f}% of data)")
            
            return insights
            
        except Exception as e:
            return [f"Error generating statistical insights: {str(e)}"]
    
    def _analyze_correlations(self, data: pd.DataFrame) -> List[str]:
        """Analyze correlations between numeric variables"""
        try:
            insights = []
            numeric_cols = data.select_dtypes(include=[np.number]).columns
            
            if len(numeric_cols) < 2:
                return ["Not enough numeric columns for correlation analysis"]
            
            # Calculate correlation matrix
            corr_matrix = data[numeric_cols].corr()
            
            # Find strong correlations
            strong_correlations = []
            for i in range(len(corr_matrix.columns)):
                for j in range(i+1, len(corr_matrix.columns)):
                    corr_val = corr_matrix.iloc[i, j]
                    if abs(corr_val) > self.correlation_threshold:
                        col1, col2 = corr_matrix.columns[i], corr_matrix.columns[j]
                        strong_correlations.append((col1, col2, corr_val))
            
            # Generate insights
            if strong_correlations:
                for col1, col2, corr_val in strong_correlations:
                    direction = "positive" if corr_val > 0 else "negative"
                    insights.append(f"Strong {direction} correlation between '{col1}' and '{col2}' (r={corr_val:.3f})")
            else:
                insights.append("No strong correlations found between numeric variables")
            
            return insights
            
        except Exception as e:
            return [f"Error analyzing correlations: {str(e)}"]
    
    def _analyze_trends(self, data: pd.DataFrame) -> List[str]:
        """Analyze trends in data"""
        try:
            insights = []
            
            # Check for potential time-based columns
            date_columns = self._detect_date_columns(data)
            numeric_cols = data.select_dtypes(include=[np.number]).columns
            
            if not date_columns or len(numeric_cols) == 0:
                return ["No time-based trends can be analyzed"]
            
            for date_col in date_columns:
                try:
                    # Convert to datetime
                    data_copy = data.copy()
                    data_copy[date_col] = pd.to_datetime(data_copy[date_col])
                    data_copy = data_copy.sort_values(date_col)
                    
                    for num_col in numeric_cols:
                        # Calculate trend
                        x = np.arange(len(data_copy))
                        y = data_copy[num_col].values
                        
                        # Remove NaN values
                        mask = ~np.isnan(y)
                        if mask.sum() < 3:
                            continue
                        
                        x_clean, y_clean = x[mask], y[mask]
                        
                        # Linear regression
                        slope, intercept, r_value, p_value, std_err = stats.linregress(x_clean, y_clean)
                        
                        if p_value < self.significance_level:
                            direction = "increasing" if slope > 0 else "decreasing"
                            insights.append(f"Significant {direction} trend in '{num_col}' over time (p<{self.significance_level})")
                
                except Exception:
                    continue
            
            return insights if insights else ["No significant trends detected"]
            
        except Exception as e:
            return [f"Error analyzing trends: {str(e)}"]
    
    def _detect_outliers(self, data: pd.DataFrame) -> Dict[str, int]:
        """Detect outliers in numeric columns"""
        try:
            outlier_counts = {}
            numeric_cols = data.select_dtypes(include=[np.number]).columns
            
            for col in numeric_cols:
                series = data[col].dropna()
                if len(series) == 0:
                    continue
                
                # Use IQR method
                Q1 = series.quantile(0.25)
                Q3 = series.quantile(0.75)
                IQR = Q3 - Q1
                
                lower_bound = Q1 - 1.5 * IQR
                upper_bound = Q3 + 1.5 * IQR
                
                outliers = ((series < lower_bound) | (series > upper_bound)).sum()
                outlier_counts[col] = outliers
            
            return outlier_counts
            
        except Exception as e:
            return {'error': str(e)}
    
    def _analyze_distributions(self, data: pd.DataFrame) -> List[str]:
        """Analyze distribution patterns"""
        try:
            insights = []
            numeric_cols = data.select_dtypes(include=[np.number]).columns
            
            for col in numeric_cols:
                series = data[col].dropna()
                if len(series) < 10:
                    continue
                
                # Test for normality
                try:
                    statistic, p_value = stats.normaltest(series)
                    if p_value > self.significance_level:
                        insights.append(f"Column '{col}' appears to be normally distributed")
                    else:
                        insights.append(f"Column '{col}' is not normally distributed")
                except Exception:
                    continue
                
                # Check for uniform distribution
                try:
                    # Simple check for uniform distribution
                    hist, bin_edges = np.histogram(series, bins=10)
                    expected_count = len(series) / 10
                    chi2_stat = np.sum((hist - expected_count)**2 / expected_count)
                    if chi2_stat < 15:  # Rough threshold
                        insights.append(f"Column '{col}' may have a uniform distribution")
                except Exception:
                    continue
            
            return insights
            
        except Exception as e:
            return [f"Error analyzing distributions: {str(e)}"]
    
    def _analyze_categorical_data(self, data: pd.DataFrame) -> List[str]:
        """Analyze categorical data patterns"""
        try:
            insights = []
            categorical_cols = data.select_dtypes(include=['object']).columns
            
            for col in categorical_cols:
                series = data[col].dropna()
                if len(series) == 0:
                    continue
                
                # Unique values analysis
                unique_count = series.nunique()
                total_count = len(series)
                
                if unique_count == 1:
                    insights.append(f"Column '{col}' has only one unique value")
                elif unique_count == total_count:
                    insights.append(f"Column '{col}' has all unique values (potential identifier)")
                elif unique_count / total_count < 0.05:
                    insights.append(f"Column '{col}' has low cardinality ({unique_count} unique values)")
                elif unique_count / total_count > 0.95:
                    insights.append(f"Column '{col}' has high cardinality ({unique_count} unique values)")
                
                # Value distribution analysis
                value_counts = series.value_counts()
                top_value_pct = (value_counts.iloc[0] / total_count) * 100
                
                if top_value_pct > 80:
                    insights.append(f"Column '{col}' is dominated by one value ({top_value_pct:.1f}%)")
                
                # Check for potential categories
                if 2 <= unique_count <= 10:
                    insights.append(f"Column '{col}' appears to be categorical with {unique_count} categories")
            
            return insights
            
        except Exception as e:
            return [f"Error analyzing categorical data: {str(e)}"]
    
    def _detect_date_columns(self, data: pd.DataFrame) -> List[str]:
        """Detect potential date columns"""
        try:
            date_columns = []
            
            for col in data.columns:
                if pd.api.types.is_datetime64_any_dtype(data[col]):
                    date_columns.append(col)
                    continue
                
                # Try to convert to datetime
                try:
                    sample_data = data[col].dropna().head(10)
                    pd.to_datetime(sample_data)
                    date_columns.append(col)
                except:
                    continue
            
            return date_columns
            
        except Exception:
            return []
    
    def generate_summary_report(self, data: pd.DataFrame) -> str:
        """Generate a comprehensive summary report"""
        try:
            insights = self.generate_insights(data)
            
            report = []
            report.append("DATA ANALYTICS SUMMARY REPORT")
            report.append("=" * 50)
            
            # Basic statistics
            basic_stats = insights.get('basic_stats', {})
            report.append(f"Total Records: {basic_stats.get('total_records', 0):,}")
            report.append(f"Total Columns: {basic_stats.get('total_columns', 0)}")
            report.append(f"Memory Usage: {basic_stats.get('memory_usage_mb', 0):.2f} MB")
            report.append("")
            
            # Data quality
            quality = insights.get('quality_insights', {})
            report.append("DATA QUALITY:")
            report.append(f"- Completeness Score: {quality.get('completeness_score', 0):.1f}%")
            report.append(f"- Missing Values: {quality.get('missing_data', {})}")
            report.append(f"- Duplicate Records: {quality.get('duplicates', 0)}")
            report.append("")
            
            # Key insights
            stat_insights = insights.get('statistical_insights', [])
            if stat_insights:
                report.append("KEY STATISTICAL INSIGHTS:")
                for insight in stat_insights[:5]:  # Top 5 insights
                    report.append(f"- {insight}")
                report.append("")
            
            # Correlations
            corr_insights = insights.get('correlation_insights', [])
            if corr_insights:
                report.append("CORRELATION INSIGHTS:")
                for insight in corr_insights[:3]:  # Top 3 correlations
                    report.append(f"- {insight}")
                report.append("")
            
            return "\n".join(report)
            
        except Exception as e:
            return f"Error generating summary report: {str(e)}"
