import pandas as pd
import json
import io
import streamlit as st
from typing import Union, Optional

class DataIngestion:
    """Handle data ingestion from various sources"""
    
    def __init__(self):
        self.supported_formats = ['csv', 'json', 'xlsx', 'parquet']
    
    def load_csv(self, file_obj: Union[str, io.StringIO], **kwargs) -> pd.DataFrame:
        """Load data from CSV file"""
        try:
            # Handle different input types
            if hasattr(file_obj, 'read'):
                data = pd.read_csv(file_obj, **kwargs)
            else:
                data = pd.read_csv(file_obj, **kwargs)
            
            # Basic validation
            if data.empty:
                raise ValueError("CSV file is empty")
            
            return data
            
        except Exception as e:
            raise Exception(f"Failed to load CSV: {str(e)}")
    
    def load_json(self, file_obj: Union[str, io.StringIO], **kwargs) -> pd.DataFrame:
        """Load data from JSON file"""
        try:
            if hasattr(file_obj, 'read'):
                json_data = json.load(file_obj)
            else:
                with open(file_obj, 'r') as f:
                    json_data = json.load(f)
            
            # Convert to DataFrame
            if isinstance(json_data, list):
                data = pd.DataFrame(json_data)
            elif isinstance(json_data, dict):
                # Try to flatten nested structure
                data = pd.json_normalize(json_data)
            else:
                raise ValueError("JSON format not supported")
            
            if data.empty:
                raise ValueError("JSON file contains no data")
            
            return data
            
        except Exception as e:
            raise Exception(f"Failed to load JSON: {str(e)}")
    
    def load_excel(self, file_obj: Union[str, io.BytesIO], sheet_name: Optional[str] = None, **kwargs) -> pd.DataFrame:
        """Load data from Excel file"""
        try:
            data = pd.read_excel(file_obj, sheet_name=sheet_name, **kwargs)
            
            if data.empty:
                raise ValueError("Excel file is empty")
            
            return data
            
        except Exception as e:
            raise Exception(f"Failed to load Excel: {str(e)}")
    
    def load_parquet(self, file_obj: Union[str, io.BytesIO], **kwargs) -> pd.DataFrame:
        """Load data from Parquet file"""
        try:
            data = pd.read_parquet(file_obj, **kwargs)
            
            if data.empty:
                raise ValueError("Parquet file is empty")
            
            return data
            
        except Exception as e:
            raise Exception(f"Failed to load Parquet: {str(e)}")
    
    def validate_file_format(self, filename: str) -> bool:
        """Validate if file format is supported"""
        extension = filename.split('.')[-1].lower()
        return extension in self.supported_formats
    
    def get_file_info(self, file_obj) -> dict:
        """Get basic information about uploaded file"""
        try:
            if hasattr(file_obj, 'size'):
                size = file_obj.size
            else:
                size = len(file_obj.getvalue()) if hasattr(file_obj, 'getvalue') else 0
            
            return {
                'name': getattr(file_obj, 'name', 'unknown'),
                'size': size,
                'type': getattr(file_obj, 'type', 'unknown')
            }
        except Exception:
            return {'name': 'unknown', 'size': 0, 'type': 'unknown'}
    
    def preview_data(self, data: pd.DataFrame, num_rows: int = 5) -> dict:
        """Generate preview information for loaded data"""
        try:
            preview = {
                'shape': data.shape,
                'columns': data.columns.tolist(),
                'dtypes': data.dtypes.to_dict(),
                'head': data.head(num_rows).to_dict('records'),
                'memory_usage': data.memory_usage(deep=True).sum(),
                'missing_values': data.isnull().sum().to_dict()
            }
            return preview
        except Exception as e:
            return {'error': str(e)}
