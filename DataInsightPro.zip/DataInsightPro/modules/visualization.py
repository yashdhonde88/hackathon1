import plotly.express as px
import plotly.graph_objects as go
import plotly.figure_factory as ff
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
from typing import Optional, List, Dict, Any

class Visualization:
    """Create interactive visualizations using Plotly"""
    
    def __init__(self):
        self.default_template = "plotly_white"
        self.color_palette = px.colors.qualitative.Set2
    
    def create_line_chart(self, data: pd.DataFrame, x_col: str, y_col: str, 
                         color_col: Optional[str] = None, title: Optional[str] = None) -> go.Figure:
        """Create interactive line chart"""
        try:
            if title is None:
                title = f"{y_col} over {x_col}"
            
            fig = px.line(data, x=x_col, y=y_col, color=color_col, 
                         title=title, template=self.default_template)
            
            fig.update_layout(
                hovermode='x unified',
                showlegend=True if color_col else False
            )
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating line chart: {str(e)}")
    
    def create_bar_chart(self, data: pd.DataFrame, x_col: str, y_col: str, 
                        color_col: Optional[str] = None, title: Optional[str] = None) -> go.Figure:
        """Create interactive bar chart"""
        try:
            if title is None:
                title = f"{y_col} by {x_col}"
            
            fig = px.bar(data, x=x_col, y=y_col, color=color_col, 
                        title=title, template=self.default_template)
            
            fig.update_layout(
                showlegend=True if color_col else False
            )
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating bar chart: {str(e)}")
    
    def create_scatter_plot(self, data: pd.DataFrame, x_col: str, y_col: str, 
                           color_col: Optional[str] = None, size_col: Optional[str] = None,
                           title: Optional[str] = None) -> go.Figure:
        """Create interactive scatter plot"""
        try:
            if title is None:
                title = f"{y_col} vs {x_col}"
            
            fig = px.scatter(data, x=x_col, y=y_col, color=color_col, size=size_col,
                           title=title, template=self.default_template)
            
            fig.update_layout(
                showlegend=True if color_col else False
            )
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating scatter plot: {str(e)}")
    
    def create_histogram(self, data: pd.DataFrame, x_col: str, bins: int = 30,
                        title: Optional[str] = None) -> go.Figure:
        """Create interactive histogram"""
        try:
            if title is None:
                title = f"Distribution of {x_col}"
            
            fig = px.histogram(data, x=x_col, nbins=bins, title=title, 
                             template=self.default_template)
            
            fig.update_layout(
                showlegend=False
            )
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating histogram: {str(e)}")
    
    def create_box_plot(self, data: pd.DataFrame, y_col: str, x_col: Optional[str] = None,
                       title: Optional[str] = None) -> go.Figure:
        """Create interactive box plot"""
        try:
            if title is None:
                title = f"Box Plot of {y_col}"
                if x_col:
                    title += f" by {x_col}"
            
            fig = px.box(data, y=y_col, x=x_col, title=title, 
                        template=self.default_template)
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating box plot: {str(e)}")
    
    def create_heatmap(self, data: pd.DataFrame, title: Optional[str] = None) -> go.Figure:
        """Create correlation heatmap"""
        try:
            if title is None:
                title = "Correlation Heatmap"
            
            # Calculate correlation matrix
            corr_matrix = data.corr()
            
            fig = px.imshow(corr_matrix, text_auto=True, aspect="auto",
                          title=title, template=self.default_template,
                          color_continuous_scale='RdBu_r')
            
            fig.update_layout(
                width=600,
                height=600
            )
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating heatmap: {str(e)}")
    
    def create_pie_chart(self, data: pd.DataFrame, col: str, 
                        title: Optional[str] = None) -> go.Figure:
        """Create interactive pie chart"""
        try:
            if title is None:
                title = f"Distribution of {col}"
            
            # Get value counts
            value_counts = data[col].value_counts()
            
            fig = px.pie(values=value_counts.values, names=value_counts.index,
                        title=title, template=self.default_template)
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating pie chart: {str(e)}")
    
    def create_area_chart(self, data: pd.DataFrame, x_col: str, y_col: str,
                         title: Optional[str] = None) -> go.Figure:
        """Create interactive area chart"""
        try:
            if title is None:
                title = f"{y_col} over {x_col}"
            
            fig = px.area(data, x=x_col, y=y_col, title=title, 
                         template=self.default_template)
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating area chart: {str(e)}")
    
    def create_violin_plot(self, data: pd.DataFrame, y_col: str, x_col: Optional[str] = None,
                          title: Optional[str] = None) -> go.Figure:
        """Create interactive violin plot"""
        try:
            if title is None:
                title = f"Violin Plot of {y_col}"
                if x_col:
                    title += f" by {x_col}"
            
            fig = px.violin(data, y=y_col, x=x_col, title=title, 
                          template=self.default_template)
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating violin plot: {str(e)}")
    
    def create_dashboard(self, data: pd.DataFrame, charts_config: List[Dict[str, Any]]) -> go.Figure:
        """Create a dashboard with multiple charts"""
        try:
            n_charts = len(charts_config)
            
            # Determine subplot layout
            if n_charts <= 2:
                rows, cols = 1, n_charts
            elif n_charts <= 4:
                rows, cols = 2, 2
            else:
                rows, cols = 3, 2
            
            # Create subplots
            fig = make_subplots(
                rows=rows, cols=cols,
                subplot_titles=[config.get('title', '') for config in charts_config[:rows*cols]]
            )
            
            # Add charts to subplots
            for i, config in enumerate(charts_config[:rows*cols]):
                row = (i // cols) + 1
                col = (i % cols) + 1
                
                chart_type = config.get('type', 'line')
                
                if chart_type == 'line':
                    trace = go.Scatter(
                        x=data[config['x_col']],
                        y=data[config['y_col']],
                        mode='lines',
                        name=config.get('name', config['y_col'])
                    )
                elif chart_type == 'bar':
                    trace = go.Bar(
                        x=data[config['x_col']],
                        y=data[config['y_col']],
                        name=config.get('name', config['y_col'])
                    )
                elif chart_type == 'scatter':
                    trace = go.Scatter(
                        x=data[config['x_col']],
                        y=data[config['y_col']],
                        mode='markers',
                        name=config.get('name', config['y_col'])
                    )
                else:
                    continue
                
                fig.add_trace(trace, row=row, col=col)
            
            fig.update_layout(
                height=300 * rows,
                showlegend=True,
                template=self.default_template
            )
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating dashboard: {str(e)}")
    
    def create_time_series_plot(self, data: pd.DataFrame, date_col: str, value_col: str,
                               title: Optional[str] = None) -> go.Figure:
        """Create time series plot with trend line"""
        try:
            if title is None:
                title = f"Time Series: {value_col}"
            
            # Create base line plot
            fig = px.line(data, x=date_col, y=value_col, title=title,
                         template=self.default_template)
            
            # Add trend line
            from scipy import stats
            x_numeric = pd.to_datetime(data[date_col]).map(pd.Timestamp.timestamp)
            slope, intercept, r_value, p_value, std_err = stats.linregress(x_numeric, data[value_col])
            
            trend_line = slope * x_numeric + intercept
            
            fig.add_trace(go.Scatter(
                x=data[date_col],
                y=trend_line,
                mode='lines',
                name='Trend',
                line=dict(dash='dash', color='red')
            ))
            
            fig.update_layout(
                hovermode='x unified'
            )
            
            return fig
            
        except Exception as e:
            return self._create_error_figure(f"Error creating time series plot: {str(e)}")
    
    def _create_error_figure(self, error_message: str) -> go.Figure:
        """Create a figure showing error message"""
        fig = go.Figure()
        fig.add_annotation(
            text=error_message,
            xref="paper", yref="paper",
            x=0.5, y=0.5,
            showarrow=False,
            font=dict(size=14, color="red")
        )
        fig.update_layout(
            title="Visualization Error",
            xaxis=dict(visible=False),
            yaxis=dict(visible=False)
        )
        return fig
