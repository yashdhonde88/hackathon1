import os
import pandas as pd
from sqlalchemy import create_engine, text, inspect
from sqlalchemy.exc import SQLAlchemyError
import sqlite3
from typing import List, Optional, Dict, Any
import io

class DatabaseConnection:
    """Handle database connections and operations"""
    
    def __init__(self):
        self.engine = None
        self.connection = None
    
    def connect_postgresql(self, 
                          host: Optional[str] = None,
                          database: Optional[str] = None,
                          user: Optional[str] = None,
                          password: Optional[str] = None,
                          port: Optional[str] = None) -> Any:
        """Connect to PostgreSQL database using environment variables or parameters"""
        try:
            # Use environment variables as default
            host = host or os.getenv('PGHOST', 'localhost')
            database = database or os.getenv('PGDATABASE', 'postgres')
            user = user or os.getenv('PGUSER', 'postgres')
            password = password or os.getenv('PGPASSWORD', '')
            port = port or os.getenv('PGPORT', '5432')
            
            # Create connection string
            connection_string = f"postgresql://{user}:{password}@{host}:{port}/{database}"
            
            # Create engine
            self.engine = create_engine(connection_string)
            self.connection = self.engine.connect()
            
            # Test connection
            self.connection.execute(text("SELECT 1"))
            
            return self.connection
            
        except Exception as e:
            raise Exception(f"PostgreSQL connection failed: {str(e)}")
    
    def connect_mysql(self,
                     host: str = 'localhost',
                     database: str = 'mysql',
                     user: str = 'root',
                     password: str = '',
                     port: int = 3306) -> Any:
        """Connect to MySQL database"""
        try:
            connection_string = f"mysql+pymysql://{user}:{password}@{host}:{port}/{database}"
            
            self.engine = create_engine(connection_string)
            self.connection = self.engine.connect()
            
            # Test connection
            self.connection.execute(text("SELECT 1"))
            
            return self.connection
            
        except Exception as e:
            raise Exception(f"MySQL connection failed: {str(e)}")
    
    def connect_sqlite(self, db_file: Any) -> Any:
        """Connect to SQLite database"""
        try:
            if hasattr(db_file, 'read'):
                # Handle file upload
                db_bytes = db_file.read()
                db_file_path = '/tmp/uploaded_db.sqlite'
                with open(db_file_path, 'wb') as f:
                    f.write(db_bytes)
            else:
                db_file_path = db_file
            
            connection_string = f"sqlite:///{db_file_path}"
            
            self.engine = create_engine(connection_string)
            self.connection = self.engine.connect()
            
            # Test connection
            self.connection.execute(text("SELECT 1"))
            
            return self.connection
            
        except Exception as e:
            raise Exception(f"SQLite connection failed: {str(e)}")
    
    def get_tables(self, connection: Any = None) -> List[str]:
        """Get list of tables in the database"""
        try:
            conn = connection or self.connection
            if not conn:
                raise Exception("No active database connection")
            
            inspector = inspect(conn)
            tables = inspector.get_table_names()
            
            return tables
            
        except Exception as e:
            raise Exception(f"Failed to get tables: {str(e)}")
    
    def get_table_info(self, table_name: str, connection: Any = None) -> Dict[str, Any]:
        """Get information about a specific table"""
        try:
            conn = connection or self.connection
            if not conn:
                raise Exception("No active database connection")
            
            inspector = inspect(conn)
            
            # Get columns
            columns = inspector.get_columns(table_name)
            
            # Get row count
            result = conn.execute(text(f"SELECT COUNT(*) FROM {table_name}"))
            row_count = result.fetchone()[0]
            
            return {
                'name': table_name,
                'columns': columns,
                'row_count': row_count
            }
            
        except Exception as e:
            raise Exception(f"Failed to get table info: {str(e)}")
    
    def load_table(self, connection: Any, table_name: str, limit: Optional[int] = None) -> pd.DataFrame:
        """Load data from a database table"""
        try:
            conn = connection or self.connection
            if not conn:
                raise Exception("No active database connection")
            
            # Build query
            query = f"SELECT * FROM {table_name}"
            if limit:
                query += f" LIMIT {limit}"
            
            # Load data
            data = pd.read_sql(query, conn)
            
            return data
            
        except Exception as e:
            raise Exception(f"Failed to load table: {str(e)}")
    
    def execute_query(self, query: str, connection: Any = None) -> pd.DataFrame:
        """Execute custom SQL query and return results as DataFrame"""
        try:
            conn = connection or self.connection
            if not conn:
                raise Exception("No active database connection")
            
            # Execute query
            data = pd.read_sql(query, conn)
            
            return data
            
        except Exception as e:
            raise Exception(f"Failed to execute query: {str(e)}")
    
    def write_to_table(self, data: pd.DataFrame, table_name: str, 
                      if_exists: str = 'replace', connection: Any = None) -> bool:
        """Write DataFrame to database table"""
        try:
            conn = connection or self.connection
            if not conn:
                raise Exception("No active database connection")
            
            # Write data
            data.to_sql(table_name, conn, if_exists=if_exists, index=False)
            
            return True
            
        except Exception as e:
            raise Exception(f"Failed to write to table: {str(e)}")
    
    def get_connection_info(self) -> Dict[str, Any]:
        """Get information about current database connection"""
        try:
            if not self.connection:
                return {'status': 'disconnected'}
            
            # Get database type
            db_type = self.engine.dialect.name
            
            # Get database URL (without password)
            url = str(self.engine.url)
            
            return {
                'status': 'connected',
                'database_type': db_type,
                'url': url
            }
            
        except Exception as e:
            return {'status': 'error', 'error': str(e)}
    
    def close_connection(self):
        """Close database connection"""
        try:
            if self.connection:
                self.connection.close()
                self.connection = None
            
            if self.engine:
                self.engine.dispose()
                self.engine = None
                
        except Exception as e:
            pass  # Ignore errors during cleanup
    
    def test_connection(self, connection: Any = None) -> bool:
        """Test if database connection is active"""
        try:
            conn = connection or self.connection
            if not conn:
                return False
            
            conn.execute(text("SELECT 1"))
            return True
            
        except Exception:
            return False
