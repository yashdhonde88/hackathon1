// Global variables
let currentUser = null;
let currentPage = 'home';
let lenis = null;

// API base URL
const API_BASE = '/api';

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    // Initialize Lenis smooth scrolling if available
    if (typeof Lenis !== 'undefined') {
        lenis = new Lenis({
            duration: 1.2,
            easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
            direction: 'vertical',
            gestureDirection: 'vertical',
            smooth: true,
            mouseMultiplier: 1,
            smoothTouch: false,
            touchMultiplier: 2,
            infinite: false,
        });

        // Smooth scrolling animation loop
        function raf(time) {
            lenis.raf(time);
            requestAnimationFrame(raf);
        }
        requestAnimationFrame(raf);
    } else {
        console.log('Lenis not available, using default scrolling');
    }

    // Check if user is logged in
    const token = localStorage.getItem('token');
    if (token) {
        try {
            const payload = JSON.parse(atob(token.split('.')[1]));
            if (payload.exp * 1000 > Date.now()) {
                currentUser = JSON.parse(localStorage.getItem('user'));
                showDashboard();
            } else {
                localStorage.removeItem('token');
                localStorage.removeItem('user');
            }
        } catch (error) {
            localStorage.removeItem('token');
            localStorage.removeItem('user');
        }
    }

    // Add smooth scrolling to navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                if (lenis) {
                    lenis.scrollTo(target);
                } else {
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            }
        });
    });

    // Set minimum date for date inputs to today
    const today = new Date().toISOString().split('T')[0];
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
        input.min = today;
    });

    // Initialize with loading historical sites
    loadHistoricalSites();
});

// Authentication Functions
function showLoginModal() {
    document.getElementById('authModal').style.display = 'block';
    showLoginForm();
}

function closeAuthModal() {
    document.getElementById('authModal').style.display = 'none';
}

function showLoginForm() {
    document.getElementById('loginForm').style.display = 'block';
    document.getElementById('signupForm').style.display = 'none';
}

function showSignupForm() {
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('signupForm').style.display = 'block';
}

// Handle login form submission
async function handleLogin(event) {
    event.preventDefault();
    showLoading();
    
    const formData = new FormData(event.target);
    const credentials = {
        email: formData.get('email'),
        password: formData.get('password')
    };

    try {
        const response = await fetch(`${API_BASE}/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(credentials)
        });

        const data = await response.json();
        
        if (response.ok) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
            currentUser = data.user;
            closeAuthModal();
            showDashboard();
            showToast('Welcome back!', 'success');
        } else {
            showToast(data.message || 'Login failed', 'error');
        }
    } catch (error) {
        showToast('Network error. Please try again.', 'error');
    } finally {
        hideLoading();
    }
}

// Handle signup form submission
async function handleSignup(event) {
    event.preventDefault();
    showLoading();
    
    const formData = new FormData(event.target);
    const userData = {
        name: formData.get('name'),
        email: formData.get('email'),
        phone: formData.get('phone'),
        password: formData.get('password')
    };

    try {
        const response = await fetch(`${API_BASE}/register`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(userData)
        });

        const data = await response.json();
        
        if (response.ok) {
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
            currentUser = data.user;
            closeAuthModal();
            showDashboard();
            showToast('Account created successfully!', 'success');
        } else {
            showToast(data.message || 'Signup failed', 'error');
        }
    } catch (error) {
        showToast('Network error. Please try again.', 'error');
    } finally {
        hideLoading();
    }
}

// Logout function
function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    currentUser = null;
    showHomePage();
    showToast('Logged out successfully', 'success');
}

// Navigation Functions
function showHomePage() {
    hideAllPages();
    document.getElementById('home').style.display = 'block';
    document.querySelector('.navbar').style.display = 'block';
    currentPage = 'home';
}

function showDashboard() {
    hideAllPages();
    document.getElementById('dashboard').style.display = 'block';
    document.querySelector('.navbar').style.display = 'none';
    document.getElementById('userName').textContent = currentUser.name;
    currentPage = 'dashboard';
}

function showCarpoolPage() {
    hideAllPages();
    document.getElementById('carpoolPage').style.display = 'block';
    document.querySelector('.navbar').style.display = 'none';
    currentPage = 'carpool';
    loadRides();
}

function showTravelBuddyPage() {
    hideAllPages();
    document.getElementById('travelBuddyPage').style.display = 'block';
    document.querySelector('.navbar').style.display = 'none';
    currentPage = 'travelBuddy';
    loadTravelPlans();
}

function showHistoryPage() {
    hideAllPages();
    document.getElementById('historyPage').style.display = 'block';
    document.querySelector('.navbar').style.display = 'none';
    currentPage = 'history';
    loadHistoricalSites();
}

function hideAllPages() {
    const pages = ['home', 'dashboard', 'carpoolPage', 'travelBuddyPage', 'historyPage'];
    pages.forEach(page => {
        const element = document.getElementById(page);
        if (element) {
            element.style.display = 'none';
        }
    });
}

// Carpool Functions
async function handleCarpoolSubmit(event) {
    event.preventDefault();
    showLoading();
    
    const formData = new FormData(event.target);
    const rideData = {
        origin: formData.get('origin'),
        destination: formData.get('destination'),
        departure_time: formData.get('departure_time'),
        available_seats: parseInt(formData.get('available_seats')),
        price_per_seat: parseFloat(formData.get('price_per_seat')) || 0,
        description: formData.get('description')
    };

    try {
        const response = await fetch(`${API_BASE}/carpool/rides`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify(rideData)
        });

        const data = await response.json();
        
        if (response.ok) {
            showToast('Ride created successfully!', 'success');
            event.target.reset();
            loadRides();
        } else {
            showToast(data.message || 'Failed to create ride', 'error');
        }
    } catch (error) {
        showToast('Network error. Please try again.', 'error');
    } finally {
        hideLoading();
    }
}

async function loadRides() {
    showLoading();
    
    try {
        const response = await fetch(`${API_BASE}/carpool/rides`);
        const rides = await response.json();
        
        if (response.ok) {
            displayRides(rides);
        } else {
            showToast('Failed to load rides', 'error');
        }
    } catch (error) {
        showToast('Network error. Please try again.', 'error');
    } finally {
        hideLoading();
    }
}

function displayRides(rides) {
    const container = document.getElementById('ridesContainer');
    
    if (rides.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: #64748b;">No rides available at the moment.</p>';
        return;
    }
    
    container.innerHTML = rides.map(ride => `
        <div class="ride-item">
            <div class="ride-header">
                <div class="ride-route">${ride.origin} → ${ride.destination}</div>
                <div class="ride-time">${formatDateTime(ride.departure_time)}</div>
            </div>
            <div class="ride-details">
                <div class="detail-item">
                    <span class="detail-label">Available Seats</span>
                    <span class="detail-value">${ride.available_seats}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Price per Seat</span>
                    <span class="detail-value">$${ride.price_per_seat || 'Free'}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Status</span>
                    <span class="detail-value">${ride.status}</span>
                </div>
            </div>
            ${ride.description ? `<div class="ride-description">${ride.description}</div>` : ''}
            <div class="driver-info">
                <div class="contact-info">
                    <span class="contact-name">${ride.driver_name}</span>
                    <span class="contact-phone">${ride.driver_phone || 'Not provided'}</span>
                </div>
                <button class="contact-btn" onclick="contactDriver('${ride.driver_name}', '${ride.driver_phone}')">
                    Contact Driver
                </button>
            </div>
        </div>
    `).join('');
}

function searchRides() {
    const origin = document.getElementById('searchOrigin').value;
    const destination = document.getElementById('searchDestination').value;
    
    const params = new URLSearchParams();
    if (origin) params.append('origin', origin);
    if (destination) params.append('destination', destination);
    
    fetch(`${API_BASE}/carpool/rides?${params}`)
        .then(response => response.json())
        .then(rides => displayRides(rides))
        .catch(error => showToast('Search failed', 'error'));
}

function contactDriver(driverName, driverPhone) {
    if (driverPhone && driverPhone !== 'Not provided') {
        window.open(`tel:${driverPhone}`, '_blank');
    } else {
        showToast('Phone number not available', 'error');
    }
}

// Travel Buddy Functions
async function handleTravelSubmit(event) {
    event.preventDefault();
    showLoading();
    
    const formData = new FormData(event.target);
    const travelData = {
        destination: formData.get('destination'),
        start_date: formData.get('start_date'),
        end_date: formData.get('end_date'),
        budget_range: formData.get('budget_range'),
        interests: formData.get('interests'),
        description: formData.get('description')
    };

    try {
        const response = await fetch(`${API_BASE}/travel/plans`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            body: JSON.stringify(travelData)
        });

        const data = await response.json();
        
        if (response.ok) {
            showToast('Travel plan created successfully!', 'success');
            event.target.reset();
            loadTravelPlans();
        } else {
            showToast(data.message || 'Failed to create travel plan', 'error');
        }
    } catch (error) {
        showToast('Network error. Please try again.', 'error');
    } finally {
        hideLoading();
    }
}

async function loadTravelPlans() {
    showLoading();
    
    try {
        const response = await fetch(`${API_BASE}/travel/plans`);
        const plans = await response.json();
        
        if (response.ok) {
            displayTravelPlans(plans);
        } else {
            showToast('Failed to load travel plans', 'error');
        }
    } catch (error) {
        showToast('Network error. Please try again.', 'error');
    } finally {
        hideLoading();
    }
}

function displayTravelPlans(plans) {
    const container = document.getElementById('travelPlansContainer');
    
    if (plans.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: #64748b;">No travel plans available at the moment.</p>';
        return;
    }
    
    container.innerHTML = plans.map(plan => `
        <div class="travel-plan-item">
            <div class="travel-plan-header">
                <div class="travel-destination">${plan.destination}</div>
                <div class="travel-dates">${formatDate(plan.start_date)} - ${formatDate(plan.end_date)}</div>
            </div>
            <div class="travel-details">
                <div class="detail-item">
                    <span class="detail-label">Budget Range</span>
                    <span class="detail-value">${plan.budget_range || 'Not specified'}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Interests</span>
                    <span class="detail-value">${plan.interests || 'Not specified'}</span>
                </div>
                <div class="detail-item">
                    <span class="detail-label">Status</span>
                    <span class="detail-value">${plan.status}</span>
                </div>
            </div>
            ${plan.description ? `<div class="travel-description">${plan.description}</div>` : ''}
            <div class="traveler-info">
                <div class="contact-info">
                    <span class="contact-name">${plan.traveler_name}</span>
                    <span class="contact-phone">${plan.traveler_phone || 'Not provided'}</span>
                </div>
                <button class="contact-btn" onclick="contactTraveler('${plan.traveler_name}', '${plan.traveler_phone}')">
                    Contact Traveler
                </button>
            </div>
        </div>
    `).join('');
}

function searchTravelPlans() {
    const destination = document.getElementById('searchTravelDestination').value;
    
    const params = new URLSearchParams();
    if (destination) params.append('destination', destination);
    
    fetch(`${API_BASE}/travel/plans?${params}`)
        .then(response => response.json())
        .then(plans => displayTravelPlans(plans))
        .catch(error => showToast('Search failed', 'error'));
}

function contactTraveler(travelerName, travelerPhone) {
    if (travelerPhone && travelerPhone !== 'Not provided') {
        window.open(`tel:${travelerPhone}`, '_blank');
    } else {
        showToast('Phone number not available', 'error');
    }
}

// Historical Sites Functions
async function loadHistoricalSites() {
    showLoading();
    
    try {
        const response = await fetch(`${API_BASE}/historical/sites`);
        const sites = await response.json();
        
        if (response.ok) {
            displayHistoricalSites(sites);
        } else {
            showToast('Failed to load historical sites', 'error');
        }
    } catch (error) {
        showToast('Network error. Please try again.', 'error');
    } finally {
        hideLoading();
    }
}

function displayHistoricalSites(sites) {
    const container = document.getElementById('historicalSitesContainer');
    
    if (sites.length === 0) {
        container.innerHTML = '<p style="text-align: center; color: #64748b;">No historical sites available at the moment.</p>';
        return;
    }
    
    container.innerHTML = sites.map(site => `
        <div class="historical-site-item">
            <div class="site-image">
                <i class="fas fa-landmark"></i>
            </div>
            <div class="site-content">
                <h3 class="site-title">${site.name}</h3>
                <p class="site-location"><i class="fas fa-map-marker-alt"></i> ${site.location}</p>
                <span class="site-period">${site.historical_period}</span>
                <p class="site-description">${site.description}</p>
                <div class="site-facts">
                    <strong>Did you know?</strong> ${site.interesting_facts}
                </div>
                <p class="site-visit-info"><i class="fas fa-clock"></i> ${site.visit_info}</p>
            </div>
        </div>
    `).join('');
}

function searchHistoricalSites() {
    const location = document.getElementById('searchLocation').value;
    
    const params = new URLSearchParams();
    if (location) params.append('location', location);
    
    fetch(`${API_BASE}/historical/sites?${params}`)
        .then(response => response.json())
        .then(sites => displayHistoricalSites(sites))
        .catch(error => showToast('Search failed', 'error'));
}

// Utility Functions
function formatDateTime(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
    });
}

function showLoading() {
    document.getElementById('loading').style.display = 'flex';
}

function hideLoading() {
    document.getElementById('loading').style.display = 'none';
}

function showToast(message, type = 'success') {
    const toast = document.getElementById('toast');
    toast.textContent = message;
    toast.className = `toast ${type} show`;
    
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// Mobile menu toggle
function toggleMobileMenu() {
    const navLinks = document.querySelector('.nav-links');
    navLinks.classList.toggle('active');
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('authModal');
    if (event.target === modal) {
        closeAuthModal();
    }
}

// Handle escape key to close modal
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape') {
        closeAuthModal();
    }
});

// Form validation
document.addEventListener('input', function(event) {
    const input = event.target;
    
    if (input.type === 'email') {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(input.value) && input.value !== '') {
            input.setCustomValidity('Please enter a valid email address');
        } else {
            input.setCustomValidity('');
        }
    }
    
    if (input.type === 'password') {
        if (input.value.length < 6 && input.value !== '') {
            input.setCustomValidity('Password must be at least 6 characters long');
        } else {
            input.setCustomValidity('');
        }
    }
    
    if (input.type === 'tel') {
        const phoneRegex = /^\+?[\d\s\-\(\)]{10,}$/;
        if (!phoneRegex.test(input.value) && input.value !== '') {
            input.setCustomValidity('Please enter a valid phone number');
        } else {
            input.setCustomValidity('');
        }
    }
});