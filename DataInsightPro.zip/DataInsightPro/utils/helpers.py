import pandas as pd
import numpy as np
from typing import Dict, Any, Optional, List, Union
import re
from datetime import datetime, timedelta
import json

def format_bytes(bytes_value: Union[int, float]) -> str:
    """
    Convert bytes to human readable format
    
    Args:
        bytes_value: Number of bytes to format
        
    Returns:
        Human readable string representation
    """
    try:
        if bytes_value == 0:
            return "0 B"
        
        # Convert to positive for calculation
        abs_bytes = abs(bytes_value)
        
        # Size units
        sizes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB']
        
        # Calculate size index
        i = 0
        while abs_bytes >= 1024 and i < len(sizes) - 1:
            abs_bytes /= 1024.0
            i += 1
        
        # Format with appropriate precision
        if abs_bytes >= 100:
            formatted = f"{abs_bytes:.0f}"
        elif abs_bytes >= 10:
            formatted = f"{abs_bytes:.1f}"
        else:
            formatted = f"{abs_bytes:.2f}"
        
        # Add negative sign back if needed
        if bytes_value < 0:
            formatted = f"-{formatted}"
        
        return f"{formatted} {sizes[i]}"
        
    except Exception:
        return "Unknown"

def get_data_summary(data: pd.DataFrame) -> Dict[str, Any]:
    """
    Get comprehensive summary of DataFrame
    
    Args:
        data: DataFrame to summarize
        
    Returns:
        Dictionary containing summary statistics
    """
    try:
        summary = {
            'basic_info': {
                'rows': len(data),
                'columns': len(data.columns),
                'memory_usage': format_bytes(data.memory_usage(deep=True).sum()),
                'size_on_disk': format_bytes(data.memory_usage(deep=True).sum())
            },
            'data_types': {
                'numeric': len(data.select_dtypes(include=[np.number]).columns),
                'categorical': len(data.select_dtypes(include=['object']).columns),
                'datetime': len(data.select_dtypes(include=['datetime64']).columns),
                'boolean': len(data.select_dtypes(include=['bool']).columns)
            },
            'missing_data': {
                'total_missing': data.isnull().sum().sum(),
                'missing_percentage': (data.isnull().sum().sum() / (len(data) * len(data.columns))) * 100,
                'columns_with_missing': data.isnull().sum()[data.isnull().sum() > 0].to_dict()
            },
            'duplicates': {
                'duplicate_rows': data.duplicated().sum(),
                'duplicate_percentage': (data.duplicated().sum() / len(data)) * 100
            }
        }
        
        # Add numeric summary if numeric columns exist
        numeric_cols = data.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) > 0:
            summary['numeric_summary'] = {
                'columns': numeric_cols.tolist(),
                'statistics': data[numeric_cols].describe().to_dict()
            }
        
        # Add categorical summary if categorical columns exist
        categorical_cols = data.select_dtypes(include=['object']).columns
        if len(categorical_cols) > 0:
            cat_summary = {}
            for col in categorical_cols:
                cat_summary[col] = {
                    'unique_values': data[col].nunique(),
                    'most_frequent': data[col].mode().iloc[0] if not data[col].mode().empty else None,
                    'frequency': data[col].value_counts().iloc[0] if not data[col].value_counts().empty else 0
                }
            summary['categorical_summary'] = cat_summary
        
        return summary
        
    except Exception as e:
        return {'error': str(e)}

def format_number(value: Union[int, float], decimal_places: int = 2) -> str:
    """
    Format number with appropriate thousand separators
    
    Args:
        value: Number to format
        decimal_places: Number of decimal places
        
    Returns:
        Formatted number string
    """
    try:
        if pd.isna(value):
            return "N/A"
        
        if isinstance(value, (int, float)):
            if value >= 1000000:
                return f"{value/1000000:.{decimal_places}f}M"
            elif value >= 1000:
                return f"{value/1000:.{decimal_places}f}K"
            else:
                return f"{value:,.{decimal_places}f}"
        
        return str(value)
        
    except Exception:
        return "N/A"

def validate_column_name(column_name: str) -> bool:
    """
    Validate if column name is valid for data operations
    
    Args:
        column_name: Column name to validate
        
    Returns:
        True if valid, False otherwise
    """
    try:
        # Check for empty or None
        if not column_name or column_name.strip() == "":
            return False
        
        # Check for valid characters (letters, numbers, underscore, space)
        if not re.match(r'^[a-zA-Z0-9_\s\-\.]+$', column_name):
            return False
        
        # Check length
        if len(column_name) > 100:
            return False
        
        return True
        
    except Exception:
        return False

def clean_column_names(data: pd.DataFrame) -> pd.DataFrame:
    """
    Clean column names to be more suitable for analysis
    
    Args:
        data: DataFrame with potentially messy column names
        
    Returns:
        DataFrame with cleaned column names
    """
    try:
        cleaned_data = data.copy()
        
        # Clean column names
        new_columns = []
        for col in cleaned_data.columns:
            # Convert to string and strip whitespace
            clean_col = str(col).strip()
            
            # Replace special characters with underscores
            clean_col = re.sub(r'[^\w\s-]', '_', clean_col)
            
            # Replace multiple spaces/underscores with single underscore
            clean_col = re.sub(r'[\s_]+', '_', clean_col)
            
            # Remove leading/trailing underscores
            clean_col = clean_col.strip('_')
            
            # Ensure it's not empty
            if not clean_col:
                clean_col = f"column_{len(new_columns)}"
            
            new_columns.append(clean_col)
        
        # Handle duplicate column names
        final_columns = []
        for i, col in enumerate(new_columns):
            if new_columns.count(col) > 1:
                count = new_columns[:i].count(col)
                if count > 0:
                    final_columns.append(f"{col}_{count}")
                else:
                    final_columns.append(col)
            else:
                final_columns.append(col)
        
        cleaned_data.columns = final_columns
        return cleaned_data
        
    except Exception:
        return data

def detect_data_types(data: pd.DataFrame) -> Dict[str, Dict[str, Any]]:
    """
    Detect and suggest appropriate data types for columns
    
    Args:
        data: DataFrame to analyze
        
    Returns:
        Dictionary with data type suggestions
    """
    try:
        suggestions = {}
        
        for col in data.columns:
            series = data[col]
            current_type = str(series.dtype)
            
            suggestions[col] = {
                'current_type': current_type,
                'suggested_type': current_type,
                'confidence': 1.0,
                'issues': []
            }
            
            # Skip if already numeric or datetime
            if pd.api.types.is_numeric_dtype(series) or pd.api.types.is_datetime64_any_dtype(series):
                continue
            
            # Check for numeric conversion
            if series.dtype == 'object':
                # Try to convert to numeric
                try:
                    numeric_series = pd.to_numeric(series, errors='coerce')
                    non_null_count = numeric_series.count()
                    total_count = series.count()
                    
                    if non_null_count / total_count > 0.8:  # 80% success rate
                        suggestions[col]['suggested_type'] = 'numeric'
                        suggestions[col]['confidence'] = non_null_count / total_count
                        if non_null_count < total_count:
                            suggestions[col]['issues'].append(f"{total_count - non_null_count} values cannot be converted to numeric")
                except Exception:
                    pass
                
                # Try to convert to datetime
                try:
                    datetime_series = pd.to_datetime(series, errors='coerce')
                    non_null_count = datetime_series.count()
                    total_count = series.count()
                    
                    if non_null_count / total_count > 0.8:  # 80% success rate
                        suggestions[col]['suggested_type'] = 'datetime'
                        suggestions[col]['confidence'] = non_null_count / total_count
                        if non_null_count < total_count:
                            suggestions[col]['issues'].append(f"{total_count - non_null_count} values cannot be converted to datetime")
                except Exception:
                    pass
        
        return suggestions
        
    except Exception as e:
        return {'error': str(e)}

def get_column_statistics(data: pd.DataFrame, column_name: str) -> Dict[str, Any]:
    """
    Get detailed statistics for a specific column
    
    Args:
        data: DataFrame containing the column
        column_name: Name of the column to analyze
        
    Returns:
        Dictionary with column statistics
    """
    try:
        if column_name not in data.columns:
            return {'error': f'Column "{column_name}" not found'}
        
        series = data[column_name]
        
        stats = {
            'name': column_name,
            'dtype': str(series.dtype),
            'count': len(series),
            'non_null_count': series.count(),
            'null_count': series.isnull().sum(),
            'null_percentage': (series.isnull().sum() / len(series)) * 100,
            'unique_count': series.nunique(),
            'memory_usage': format_bytes(series.memory_usage(deep=True))
        }
        
        # Add numeric statistics
        if pd.api.types.is_numeric_dtype(series):
            stats.update({
                'min': series.min(),
                'max': series.max(),
                'mean': series.mean(),
                'median': series.median(),
                'std': series.std(),
                'variance': series.var(),
                'skewness': series.skew(),
                'kurtosis': series.kurtosis(),
                'quantiles': {
                    '25%': series.quantile(0.25),
                    '50%': series.quantile(0.50),
                    '75%': series.quantile(0.75)
                }
            })
        
        # Add categorical statistics
        elif series.dtype == 'object':
            value_counts = series.value_counts()
            stats.update({
                'most_frequent': value_counts.index[0] if len(value_counts) > 0 else None,
                'most_frequent_count': value_counts.iloc[0] if len(value_counts) > 0 else 0,
                'least_frequent': value_counts.index[-1] if len(value_counts) > 0 else None,
                'least_frequent_count': value_counts.iloc[-1] if len(value_counts) > 0 else 0,
                'top_values': value_counts.head(10).to_dict(),
                'avg_length': series.astype(str).str.len().mean(),
                'max_length': series.astype(str).str.len().max(),
                'min_length': series.astype(str).str.len().min()
            })
        
        # Add datetime statistics
        elif pd.api.types.is_datetime64_any_dtype(series):
            stats.update({
                'min_date': series.min(),
                'max_date': series.max(),
                'date_range': series.max() - series.min(),
                'most_common_year': series.dt.year.mode().iloc[0] if not series.dt.year.mode().empty else None,
                'most_common_month': series.dt.month.mode().iloc[0] if not series.dt.month.mode().empty else None,
                'most_common_day': series.dt.day.mode().iloc[0] if not series.dt.day.mode().empty else None
            })
        
        return stats
        
    except Exception as e:
        return {'error': str(e)}

def create_sample_data(rows: int = 100) -> pd.DataFrame:
    """
    Create sample data for demonstration purposes
    
    Args:
        rows: Number of rows to create
        
    Returns:
        DataFrame with sample data
    """
    try:
        np.random.seed(42)  # For reproducibility
        
        # Generate sample data
        data = {
            'id': range(1, rows + 1),
            'name': [f'Item_{i}' for i in range(1, rows + 1)],
            'value': np.random.normal(100, 15, rows),
            'category': np.random.choice(['A', 'B', 'C', 'D'], rows),
            'date': pd.date_range('2023-01-01', periods=rows, freq='D'),
            'is_active': np.random.choice([True, False], rows),
            'score': np.random.randint(1, 101, rows)
        }
        
        # Add some missing values
        mask = np.random.random(rows) < 0.1
        data['value'][mask] = np.nan
        
        return pd.DataFrame(data)
        
    except Exception as e:
        return pd.DataFrame()

def export_config_to_json(config: Dict[str, Any], filename: str = 'config.json') -> str:
    """
    Export configuration to JSON string
    
    Args:
        config: Configuration dictionary
        filename: Filename for the export
        
    Returns:
        JSON string representation
    """
    try:
        # Convert numpy types to native Python types
        def convert_numpy_types(obj):
            if isinstance(obj, np.integer):
                return int(obj)
            elif isinstance(obj, np.floating):
                return float(obj)
            elif isinstance(obj, np.ndarray):
                return obj.tolist()
            elif isinstance(obj, pd.Timestamp):
                return obj.isoformat()
            elif isinstance(obj, datetime):
                return obj.isoformat()
            elif isinstance(obj, timedelta):
                return str(obj)
            return obj
        
        # Recursively convert the config
        def recursive_convert(obj):
            if isinstance(obj, dict):
                return {k: recursive_convert(v) for k, v in obj.items()}
            elif isinstance(obj, list):
                return [recursive_convert(item) for item in obj]
            else:
                return convert_numpy_types(obj)
        
        converted_config = recursive_convert(config)
        
        # Add metadata
        export_data = {
            'metadata': {
                'export_date': datetime.now().isoformat(),
                'filename': filename,
                'version': '1.0'
            },
            'config': converted_config
        }
        
        return json.dumps(export_data, indent=2, ensure_ascii=False)
        
    except Exception as e:
        return json.dumps({'error': str(e)}, indent=2)

def calculate_completeness_score(data: pd.DataFrame) -> Dict[str, Any]:
    """
    Calculate data completeness score
    
    Args:
        data: DataFrame to analyze
        
    Returns:
        Dictionary with completeness information
    """
    try:
        total_cells = data.shape[0] * data.shape[1]
        missing_cells = data.isnull().sum().sum()
        
        completeness = {
            'total_cells': total_cells,
            'missing_cells': missing_cells,
            'complete_cells': total_cells - missing_cells,
            'completeness_percentage': ((total_cells - missing_cells) / total_cells) * 100 if total_cells > 0 else 0,
            'column_completeness': {}
        }
        
        # Calculate completeness for each column
        for col in data.columns:
            col_total = len(data[col])
            col_missing = data[col].isnull().sum()
            col_complete = col_total - col_missing
            
            completeness['column_completeness'][col] = {
                'total': col_total,
                'missing': col_missing,
                'complete': col_complete,
                'percentage': (col_complete / col_total) * 100 if col_total > 0 else 0
            }
        
        return completeness
        
    except Exception as e:
        return {'error': str(e)}

def safe_division(numerator: Union[int, float], denominator: Union[int, float], 
                 default_value: Union[int, float] = 0) -> Union[int, float]:
    """
    Safely divide two numbers, handling division by zero
    
    Args:
        numerator: Number to divide
        denominator: Number to divide by
        default_value: Value to return if division by zero
        
    Returns:
        Result of division or default value
    """
    try:
        if denominator == 0:
            return default_value
        return numerator / denominator
    except Exception:
        return default_value

def truncate_string(text: str, max_length: int = 50, suffix: str = "...") -> str:
    """
    Truncate string to specified length with suffix
    
    Args:
        text: String to truncate
        max_length: Maximum length
        suffix: Suffix to add if truncated
        
    Returns:
        Truncated string
    """
    try:
        if len(text) <= max_length:
            return text
        
        return text[:max_length - len(suffix)] + suffix
        
    except Exception:
        return str(text)
