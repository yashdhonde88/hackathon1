import pandas as pd
import numpy as np
from typing import Dict, List, Any, Optional, Tuple
import re
from datetime import datetime

class DataValidator:
    """Validate data quality and integrity"""
    
    def __init__(self):
        self.validation_rules = {
            'required': self._check_required,
            'numeric': self._check_numeric,
            'date': self._check_date,
            'email': self._check_email,
            'url': self._check_url,
            'range': self._check_range,
            'length': self._check_length,
            'pattern': self._check_pattern,
            'unique': self._check_unique
        }
    
    def validate_data(self, data: pd.DataFrame, rules: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Validate data against specified rules"""
        try:
            if rules is None:
                rules = self._generate_default_rules(data)
            
            validation_results = {
                'valid': True,
                'errors': [],
                'warnings': [],
                'summary': {}
            }
            
            for column, column_rules in rules.items():
                if column not in data.columns:
                    validation_results['errors'].append(f"Column '{column}' not found in data")
                    continue
                
                column_results = self._validate_column(data[column], column_rules)
                validation_results['summary'][column] = column_results
                
                if column_results['errors']:
                    validation_results['valid'] = False
                    validation_results['errors'].extend(column_results['errors'])
                
                if column_results['warnings']:
                    validation_results['warnings'].extend(column_results['warnings'])
            
            return validation_results
            
        except Exception as e:
            return {'valid': False, 'error': str(e)}
    
    def _validate_column(self, series: pd.Series, rules: Dict[str, Any]) -> Dict[str, Any]:
        """Validate a single column against rules"""
        results = {
            'valid': True,
            'errors': [],
            'warnings': []
        }
        
        for rule_name, rule_params in rules.items():
            if rule_name in self.validation_rules:
                try:
                    is_valid, message = self.validation_rules[rule_name](series, rule_params)
                    if not is_valid:
                        results['valid'] = False
                        results['errors'].append(message)
                except Exception as e:
                    results['warnings'].append(f"Rule '{rule_name}' failed: {str(e)}")
        
        return results
    
    def _generate_default_rules(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Generate default validation rules based on data types"""
        rules = {}
        
        for column in data.columns:
            column_rules = {}
            dtype = data[column].dtype
            
            # Check for missing values
            if data[column].isnull().any():
                column_rules['required'] = False
            
            # Type-specific rules
            if pd.api.types.is_numeric_dtype(dtype):
                column_rules['numeric'] = True
                column_rules['range'] = {
                    'min': data[column].min(),
                    'max': data[column].max()
                }
            
            elif pd.api.types.is_datetime64_any_dtype(dtype):
                column_rules['date'] = True
            
            elif dtype == 'object':
                # Check for potential email or URL patterns
                sample_values = data[column].dropna().head(100)
                if self._looks_like_email(sample_values):
                    column_rules['email'] = True
                elif self._looks_like_url(sample_values):
                    column_rules['url'] = True
                else:
                    max_length = data[column].str.len().max()
                    column_rules['length'] = {'max': max_length}
            
            rules[column] = column_rules
        
        return rules
    
    def _check_required(self, series: pd.Series, required: bool) -> Tuple[bool, str]:
        """Check if required values are present"""
        if required:
            null_count = series.isnull().sum()
            if null_count > 0:
                return False, f"Found {null_count} missing values in required column"
        return True, "OK"
    
    def _check_numeric(self, series: pd.Series, should_be_numeric: bool) -> Tuple[bool, str]:
        """Check if values are numeric"""
        if should_be_numeric:
            if not pd.api.types.is_numeric_dtype(series.dtype):
                return False, "Column should be numeric"
            
            # Check for infinite values
            if np.isinf(series).any():
                return False, "Column contains infinite values"
        
        return True, "OK"
    
    def _check_date(self, series: pd.Series, should_be_date: bool) -> Tuple[bool, str]:
        """Check if values are valid dates"""
        if should_be_date:
            if not pd.api.types.is_datetime64_any_dtype(series.dtype):
                # Try to convert to datetime
                try:
                    pd.to_datetime(series.dropna())
                except:
                    return False, "Column contains invalid date values"
        
        return True, "OK"
    
    def _check_email(self, series: pd.Series, should_be_email: bool) -> Tuple[bool, str]:
        """Check if values are valid email addresses"""
        if should_be_email:
            email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
            invalid_emails = series.dropna().apply(lambda x: not re.match(email_pattern, str(x)))
            
            if invalid_emails.any():
                invalid_count = invalid_emails.sum()
                return False, f"Found {invalid_count} invalid email addresses"
        
        return True, "OK"
    
    def _check_url(self, series: pd.Series, should_be_url: bool) -> Tuple[bool, str]:
        """Check if values are valid URLs"""
        if should_be_url:
            url_pattern = r'^https?://(?:[-\w.])+(?:\:[0-9]+)?(?:/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:\#(?:[\w.])*)?)?$'
            invalid_urls = series.dropna().apply(lambda x: not re.match(url_pattern, str(x)))
            
            if invalid_urls.any():
                invalid_count = invalid_urls.sum()
                return False, f"Found {invalid_count} invalid URLs"
        
        return True, "OK"
    
    def _check_range(self, series: pd.Series, range_params: Dict[str, Any]) -> Tuple[bool, str]:
        """Check if values are within specified range"""
        if 'min' in range_params:
            min_val = range_params['min']
            if (series < min_val).any():
                return False, f"Found values below minimum {min_val}"
        
        if 'max' in range_params:
            max_val = range_params['max']
            if (series > max_val).any():
                return False, f"Found values above maximum {max_val}"
        
        return True, "OK"
    
    def _check_length(self, series: pd.Series, length_params: Dict[str, Any]) -> Tuple[bool, str]:
        """Check if string values have valid length"""
        str_series = series.astype(str)
        
        if 'min' in length_params:
            min_len = length_params['min']
            if (str_series.str.len() < min_len).any():
                return False, f"Found values shorter than {min_len} characters"
        
        if 'max' in length_params:
            max_len = length_params['max']
            if (str_series.str.len() > max_len).any():
                return False, f"Found values longer than {max_len} characters"
        
        return True, "OK"
    
    def _check_pattern(self, series: pd.Series, pattern: str) -> Tuple[bool, str]:
        """Check if values match specified pattern"""
        try:
            str_series = series.astype(str)
            invalid_pattern = ~str_series.str.match(pattern)
            
            if invalid_pattern.any():
                invalid_count = invalid_pattern.sum()
                return False, f"Found {invalid_count} values not matching pattern"
            
            return True, "OK"
            
        except Exception as e:
            return False, f"Pattern validation failed: {str(e)}"
    
    def _check_unique(self, series: pd.Series, should_be_unique: bool) -> Tuple[bool, str]:
        """Check if values are unique"""
        if should_be_unique:
            duplicates = series.duplicated().sum()
            if duplicates > 0:
                return False, f"Found {duplicates} duplicate values"
        
        return True, "OK"
    
    def _looks_like_email(self, sample_values: pd.Series) -> bool:
        """Check if sample values look like email addresses"""
        if len(sample_values) == 0:
            return False
        
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        matches = sample_values.apply(lambda x: bool(re.match(email_pattern, str(x))))
        
        return matches.sum() / len(matches) > 0.8
    
    def _looks_like_url(self, sample_values: pd.Series) -> bool:
        """Check if sample values look like URLs"""
        if len(sample_values) == 0:
            return False
        
        url_pattern = r'^https?://'
        matches = sample_values.apply(lambda x: bool(re.match(url_pattern, str(x))))
        
        return matches.sum() / len(matches) > 0.8
    
    def check_data_consistency(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Check for data consistency issues"""
        try:
            consistency_report = {
                'duplicate_rows': data.duplicated().sum(),
                'missing_patterns': {},
                'data_type_issues': [],
                'value_consistency': {}
            }
            
            # Check missing data patterns
            for column in data.columns:
                missing_count = data[column].isnull().sum()
                if missing_count > 0:
                    consistency_report['missing_patterns'][column] = {
                        'count': missing_count,
                        'percentage': (missing_count / len(data)) * 100
                    }
            
            # Check data type consistency
            for column in data.columns:
                if data[column].dtype == 'object':
                    # Check if numeric values are stored as strings
                    sample_values = data[column].dropna().head(100)
                    numeric_count = sum(1 for val in sample_values if str(val).replace('.', '').replace('-', '').isdigit())
                    if numeric_count > len(sample_values) * 0.8:
                        consistency_report['data_type_issues'].append(f"Column '{column}' may contain numeric values stored as strings")
            
            # Check value consistency for categorical columns
            categorical_columns = data.select_dtypes(include=['object']).columns
            for column in categorical_columns:
                unique_values = data[column].dropna().unique()
                if 2 <= len(unique_values) <= 20:
                    # Check for similar values (potential typos)
                    similar_values = self._find_similar_values(unique_values)
                    if similar_values:
                        consistency_report['value_consistency'][column] = similar_values
            
            return consistency_report
            
        except Exception as e:
            return {'error': str(e)}
    
    def _find_similar_values(self, values: List[str]) -> List[Tuple[str, str]]:
        """Find similar values that might be typos"""
        from difflib import SequenceMatcher
        
        similar_pairs = []
        
        for i, val1 in enumerate(values):
            for val2 in values[i+1:]:
                similarity = SequenceMatcher(None, str(val1).lower(), str(val2).lower()).ratio()
                if 0.8 <= similarity < 1.0:
                    similar_pairs.append((val1, val2))
        
        return similar_pairs
