import pandas as pd
import json
from typing import Dict, Any, Optional, List
from modules.data_analysis import DataAnalysis
from modules.insights import InsightGenerator
from modules.export import DataExport

class DataAPI:
    """API interface for data operations"""
    
    def __init__(self):
        self.data_analysis = DataAnalysis()
        self.insight_generator = InsightGenerator()
        self.data_export = DataExport()
    
    def get_data_summary(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Get summary statistics for the dataset"""
        try:
            summary = {
                'basic_info': {
                    'shape': data.shape,
                    'columns': data.columns.tolist(),
                    'memory_usage': data.memory_usage(deep=True).sum(),
                    'missing_values': data.isnull().sum().to_dict()
                },
                'numeric_summary': {},
                'categorical_summary': {}
            }
            
            # Numeric columns summary
            numeric_cols = data.select_dtypes(include=['number']).columns
            if len(numeric_cols) > 0:
                summary['numeric_summary'] = data[numeric_cols].describe().to_dict()
            
            # Categorical columns summary
            categorical_cols = data.select_dtypes(include=['object']).columns
            for col in categorical_cols:
                summary['categorical_summary'][col] = {
                    'unique_values': data[col].nunique(),
                    'top_values': data[col].value_counts().head(5).to_dict()
                }
            
            return summary
            
        except Exception as e:
            return {'error': str(e)}
    
    def query_data(self, data: pd.DataFrame, query_params: Dict[str, Any]) -> Dict[str, Any]:
        """Query data with filters and return results"""
        try:
            filtered_data = data.copy()
            
            # Apply column selection
            if 'columns' in query_params and query_params['columns']:
                available_columns = [col for col in query_params['columns'] if col in data.columns]
                filtered_data = filtered_data[available_columns]
            
            # Apply filters
            if 'filters' in query_params:
                for column, filter_config in query_params['filters'].items():
                    if column not in filtered_data.columns:
                        continue
                    
                    if isinstance(filter_config, dict):
                        # Range filter
                        if 'min' in filter_config and 'max' in filter_config:
                            filtered_data = filtered_data[
                                (filtered_data[column] >= filter_config['min']) &
                                (filtered_data[column] <= filter_config['max'])
                            ]
                        
                        # Value filter
                        elif 'values' in filter_config:
                            filtered_data = filtered_data[
                                filtered_data[column].isin(filter_config['values'])
                            ]
            
            # Apply sorting
            if 'sort_by' in query_params and query_params['sort_by'] in filtered_data.columns:
                ascending = query_params.get('sort_order', 'asc') == 'asc'
                filtered_data = filtered_data.sort_values(query_params['sort_by'], ascending=ascending)
            
            # Apply pagination
            limit = query_params.get('limit', 100)
            offset = query_params.get('offset', 0)
            
            paginated_data = filtered_data.iloc[offset:offset + limit]
            
            return {
                'data': paginated_data.to_dict('records'),
                'total_records': len(filtered_data),
                'returned_records': len(paginated_data),
                'offset': offset,
                'limit': limit
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def export_data(self, data: pd.DataFrame, export_format: str = 'csv',
                   export_params: Optional[Dict[str, Any]] = None) -> str:
        """Export data in specified format"""
        try:
            if export_params is None:
                export_params = {}
            
            if export_format.lower() == 'csv':
                return self.data_export.to_csv(data, **export_params)
            elif export_format.lower() == 'json':
                return self.data_export.to_json(data, **export_params)
            elif export_format.lower() == 'html':
                return self.data_export.to_html(data, **export_params)
            else:
                raise ValueError(f"Unsupported export format: {export_format}")
                
        except Exception as e:
            return json.dumps({'error': str(e)})
    
    def generate_insights(self, data: pd.DataFrame) -> Dict[str, Any]:
        """Generate insights for the dataset"""
        try:
            insights = self.insight_generator.generate_insights(data)
            return insights
            
        except Exception as e:
            return {'error': str(e)}
    
    def analyze_correlations(self, data: pd.DataFrame, method: str = 'pearson') -> Dict[str, Any]:
        """Analyze correlations between variables"""
        try:
            numeric_data = data.select_dtypes(include=['number'])
            
            if numeric_data.empty:
                return {'error': 'No numeric columns found for correlation analysis'}
            
            correlation_matrix = self.data_analysis.calculate_correlation(numeric_data, method)
            
            return {
                'correlation_matrix': correlation_matrix.to_dict(),
                'method': method,
                'columns': correlation_matrix.columns.tolist()
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def detect_outliers(self, data: pd.DataFrame, method: str = 'iqr') -> Dict[str, Any]:
        """Detect outliers in numeric columns"""
        try:
            outliers = self.data_analysis.detect_outliers(data, method=method)
            return {
                'outliers': outliers,
                'method': method
            }
            
        except Exception as e:
            return {'error': str(e)}
    
    def get_column_info(self, data: pd.DataFrame, column_name: str) -> Dict[str, Any]:
        """Get detailed information about a specific column"""
        try:
            if column_name not in data.columns:
                return {'error': f'Column "{column_name}" not found'}
            
            column_data = data[column_name]
            
            info = {
                'name': column_name,
                'dtype': str(column_data.dtype),
                'non_null_count': column_data.count(),
                'null_count': column_data.isnull().sum(),
                'unique_count': column_data.nunique(),
                'memory_usage': column_data.memory_usage(deep=True)
            }
            
            # Additional info for numeric columns
            if pd.api.types.is_numeric_dtype(column_data):
                info.update({
                    'min': column_data.min(),
                    'max': column_data.max(),
                    'mean': column_data.mean(),
                    'median': column_data.median(),
                    'std': column_data.std(),
                    'skewness': column_data.skew(),
                    'kurtosis': column_data.kurtosis()
                })
            
            # Additional info for categorical columns
            else:
                info.update({
                    'top_values': column_data.value_counts().head(10).to_dict(),
                    'sample_values': column_data.dropna().head(10).tolist()
                })
            
            return info
            
        except Exception as e:
            return {'error': str(e)}

# API endpoint functions for use with web frameworks
def get_data_summary_api(data: pd.DataFrame) -> Dict[str, Any]:
    """API endpoint for data summary"""
    api = DataAPI()
    return api.get_data_summary(data)

def query_data_api(data: pd.DataFrame, query_params: Dict[str, Any]) -> Dict[str, Any]:
    """API endpoint for data querying"""
    api = DataAPI()
    return api.query_data(data, query_params)

def export_data_api(data: pd.DataFrame, export_format: str) -> str:
    """API endpoint for data export"""
    api = DataAPI()
    return api.export_data(data, export_format)

def generate_insights_api(data: pd.DataFrame) -> Dict[str, Any]:
    """API endpoint for insights generation"""
    api = DataAPI()
    return api.generate_insights(data)

def analyze_correlations_api(data: pd.DataFrame, method: str = 'pearson') -> Dict[str, Any]:
    """API endpoint for correlation analysis"""
    api = DataAPI()
    return api.analyze_correlations(data, method)

def detect_outliers_api(data: pd.DataFrame, method: str = 'iqr') -> Dict[str, Any]:
    """API endpoint for outlier detection"""
    api = DataAPI()
    return api.detect_outliers(data, method)

def get_column_info_api(data: pd.DataFrame, column_name: str) -> Dict[str, Any]:
    """API endpoint for column information"""
    api = DataAPI()
    return api.get_column_info(data, column_name)
